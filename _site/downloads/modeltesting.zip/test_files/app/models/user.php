<?php
class User extends AppModel {
	var $name = 'User';

	var $validate = array(
		'username' => array(
			'rule' => 'notEmpty',
			'message' => 'Username must not be empty',
			'required' => true
		),
		'password' => array(
			'rule' => 'matchesConf',
			'message' => "Passwords don't match",
			'required' => true
		),
		'email' => array(
			'unique' => array(
				'rule' => 'isUnique',
				'message' => 'Email is already taken',
				'required' => true
			),
			'email' => array(
				'rule' => 'email',
				'message' => 'Not a valid email address'
			)
		)
	);

	var $hasMany = array(
		'Publication' => array(
			'foreignKey' => 'user_id',
			'dependent' => true
		)
	);

	function matchesConf($check) {
		if (! empty($this->data['User']['passConf']) ) {
			return $check['password'] == $this->data['User']['passConf'];
		}
		return false;
	}
}