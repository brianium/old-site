<?php
class Publication extends AppModel {
	var $name = 'Publication';

	var $belongsTo = 'User';
}
?>