<?php
App::import('Model','User');
class UserTestCase extends CakeTestCase {
	
	var $fixtures = array('app.user','app.publication');

	function startCase() {
		$this->User = ClassRegistry::init('User');
	}

	function endCase() {
		ClassRegistry::flush();
	}

	function testUserDoesNotValidateWhenNoPassConf() {
		$this->User->create(array(
			'username' => 'bscaturro',
			'email' => 'bscaturro@gmail.com',
			'password' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
	}

	function testUserDoesNotValidateWhenPassConfDoesntMatch() {
		$this->User->create(array(
			'username' => 'bscaturro',
			'email' => 'bscaturro@gmail.com',
			'password' => 'pass',
			'passConf' => 'pazz',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
	}

	function testUserDoesValidateWhenPassConfMatches() {
		$this->User->create(array(
			'username' => 'bscaturro',
			'email' => 'bscaturro@gmail.com',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertTrue($this->User->validates());
	}

	function testUserEmailMustBeUnique() {
		$this->User->create(array(
			'username' => 'bscaturro',
			'email' => 'scaturrob@gmail.com',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
	}

	function testUserEmailIsValidEmail() {
		$this->User->create(array(
			'username' => 'bscaturro',
			'email' => 'scaturrob.email.awesome',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
	}
    
    function testUserNameCannotBeEmpty() {
    	$this->User->create(array(
			'username' => '',
			'email' => 'scaturrob@gmail.com',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
    }

    function testUserNameCannotBeOmitted() {
    	$this->User->create(array(
			'email' => 'scaturrob@gmail.com',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
    }

    function testEmailCannotBeEmpty() {
    	$this->User->create(array(
    		'username' => 'brian',
			'email' => '',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
    }

    function testEmailCannotBeOmitted() {
    	$this->User->create(array(
    		'username' => 'brian',
			'password' => 'pass',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
    }

    function testPasswordCannotBeEmpty() {
    	$this->User->create(array(
    		'username' => 'brian',
			'email' => 'bscaturro@gmail.com',
			'password' => '',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
    }

    function testPasswordCannotBeOmitted() {
    	$this->User->create(array(
    		'username' => 'brian',
    		'email' => 'bscaturro@gmail.com',
			'passConf' => 'pass',
			'cdate' => null
		));
		$this->assertFalse($this->User->validates());
    }
        
}
?>