<?php
class UserFixture extends CakeTestFixture {
	var $name = 'User';

	var $fields = array(
		'id' => array('type' => 'integer','key' => 'primary'),
		'username' => array('type' => 'string','length' => 100, 'null' => false),
		'password' => array('type' => 'string','length' => 40, 'null' => false),
		'email' => array('type' => 'string','length' => 255, 'null' => false),
		'cdate' => array('type' => 'timestamp','null' => true,'default' => null)
	);

	var $records = array(
		array('id' => 1,'username' => 'bscaturro','email' => 'scaturrob@gmail.com','password' => 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3','cdate' => '2011-11-16 06:59:22')
	);
}
?>