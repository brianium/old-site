<?php
class PublicationFixture extends CakeTestFixture {
	var $name = 'Publication';

	var $fields = array(
		'id' => array('type' => 'integer','key' => 'primary'),
		'user_id' => array('type' => 'integer','null' => false),
		'title' => array('type' => 'string','length' => 255, 'null' => false),
		'author' => array('type' => 'string','length' => 100, 'null' => true),
		'link' => array('type' => 'string','null' => true,'length' => 255),
		'cdate' => array('type' => 'timestamp','null' => true,'default' => null)
	);
}
?>