<?php
/*
Plugin Name: Delicious Links Widget
Plugin URI: http://brianscaturro.com/delicious-links.zip
Description: Show your latest links from del.icio.us
Author: Brian Scaturro
Author URI: http://brianscaturro.com/
Text Domain: delicious_links
Version: 1.0
*/

function delicious_links_init() {
	$css = plugins_url('css/delicious_links.css',__FILE__);
	wp_enqueue_style('delicious_links',$css,array(),'1.0');
	load_plugin_textdomain( 'delicious_links', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action('init','delicious_links_init');

class DeliciousLinks_Widget extends  WP_Widget {

	protected $cache;

	function __construct() {
		parent::__construct('delicious_links','Delicious Links',array(
			'description' => 'Displays recent del.icio.us links'
		));
		$this->cache = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'cache.xml';
	}

	function form($instance) {
		$fields = array(
			array(
				'type' => 'text',
				'name' => 'title',
				'default' => __('Delicious Links','delicious_links'),
				'label' => __('Title','delicious_links')
			),
			array(
				'type' => 'text',
				'name' => 'user',
				'default' => __('Username','delicious_links'),
				'label' => __('Username','delicious_links')
			),
			array(
				'type' => 'text',
				'name' => 'password',
				'label' => __('Password','delicious_links')
			),
			array(
				'type' => 'select',
				'name' => 'count',
				'default' => 3,
				'label' => __('Link count','delicious_links'),
				'options' => array(1 => 1,2 => 2,3 => 3,4 => 4,5 => 5)
			)
		);
		foreach ( $fields as $field ) {
			?>
			<p>
				<label for="<?php echo $this->get_field_id($field['name']); ?>">
					<?php echo $field['label']; ?>
				</label>
				<?php
				$value = @$field['default'];
				if ( $instance && !empty($instance[$field['name']]) ) {
					$value = $instance[$field['name']];
				}
				$input = '<input type="%s" id="%s" name="%s" value="%s" class="widefat" />';
				switch ( $field['type'] ) {
					case 'text':
						$input = sprintf($input,'text',$this->get_field_id($field['name']),$this->get_field_name($field['name']),$value);
						break;
					case 'select':
						$input = sprintf('<select id="%s" name="%s">',$this->get_field_id($field['name']),$this->get_field_name($field['name']));
						foreach ( $field['options'] as $val => $opt ) {
							$option = '<option value="' . $val . '"';
							if ( $val == $value ) {
								$option .= ' selected="selected"';
							}
							$option .= '>' . $opt . '</option>';
							$input .= $option;
						}
						$input .= '</select>';
						break;
				}
				echo $input; 
				?>
			</p><?php
		}
	}

	function update($new,$old) {
		$instance = $old;
		foreach ( $new as $key => $value ) {
			$instance[$key] = strip_tags($value);
		}
		return $instance;
	}

	function widget($args,$instance) {
		extract($args);
		$user = $instance['user'];
		$password = $instance['password'];
		$count = $instance['count'];

		$endpoint = "https://$user:$password@api.del.icio.us/v1/posts/recent?count=$count";
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$endpoint);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,true);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,true);
		//del.icio.us api requires a recognizable user agent
		curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
		$result = curl_exec($ch);
		if (!curl_errno($ch)) {
			$status = curl_getinfo($ch,CURLINFO_HTTP_CODE);
			if ( $status == 200 ) {
				if ( $result ) {
					file_put_contents($this->cache,$result);
					$xml = $result;	
				}
			} else if ( $status == 500 || $status == 999 ) {
				//been throttled
				$xml = file_get_contents($this->cache);
			}
		}
		if ( $xml ) {
			$posts = $this->_parseResult($xml);
			echo $before_widget;
			echo $before_title . $instance['title'] . $after_title;
			?>
			<ul class="delicious-links">
				<?php foreach( $posts as $post ): ?>
				<li><a href="<?php echo $post['href']; ?>"><?php echo $post['description']; ?></a></li>
				<?php endforeach; ?>
			</ul><?php
			echo $after_widget;
		} else {
			//there was an error
		}
	}

	function _parseResult($xml) {
		$doc = DOMDocument::loadXML($xml);
		$posts = array();
		if ( $doc ) {
			$postNodes = $doc->getElementsByTagName('post');
			$i = 0;
			while ( $postNode = $postNodes->item($i++) ) {
				$post = array(
					'description' => $postNode->getAttribute('description'),
					'extended' => $postNode->getAttribute('extended'),
					'href' => $postNode->getAttribute('href'),
					'time' => $postNode->getAttribute('time')
				);
				$posts[] = $post;
			}
		}
		return $posts;
	}
}
add_action( 'widgets_init', create_function( '', 'register_widget("DeliciousLinks_Widget");' ) );
?>