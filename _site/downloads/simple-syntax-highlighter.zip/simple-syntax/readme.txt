=== Simple Syntax Highlighter ===
Contributors: Brian Scaturro
Tags: syntax highlighter, code
Requires at least: 2.7

Just another contact form plugin. Simple but flexible.

== Description ==

Just a simple way to install and choose themes for google-code-prettyify. There are no dependencies other than
the bundled ones. Just install and start using!

== Installation ==

1. Upload the entire `syntax` folder to the `/wp-content/plugins/`
directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'Simple Syntax' menu in your WordPress settings panel.

For usage, you can also have a look at (http://google-code-prettify.googlecode.com/svn/trunk/README.html).

