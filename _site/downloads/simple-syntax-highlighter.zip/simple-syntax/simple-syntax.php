<?php
/*
Plugin Name: Simple Syntax Highlighter
Plugin URI: http://brianscaturro.com/simple-syntax.zip
Description: Simple installation of google-code-prettyify
Author: Brian Scaturro
Author URI: http://brianscaturro.com/
Text Domain: simple-syntax
Domain Path: /languages/
Version: 1.0
*/
function simple_syntax_highlighter_init() {
	load_plugin_textdomain( 'simple-syntax', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	$js = plugins_url('js/prettify.js',__FILE__);
	$prettyInit = plugins_url('js/prettyinit.js',__FILE__);
	wp_enqueue_script( 'prettify', $js, array(), '', true);
	wp_enqueue_script( 'prettyinit', $prettyInit, array('prettify'), '', true);
	$options = get_option('simple_syntax_options');
	$theme = 'prettify.css';
	$styles = array('prettify.css');
	if ( $options['theme'] && $options['theme'] != 'prettyify.css' ) {
		$styles[] = $options['theme'];
	}
	for ( $i = 0; $i < count($styles); $i++ ) {
		$css = plugins_url('themes/' . $styles[$i],__FILE__);
		wp_enqueue_style("prettify-$i", $css, array(), '0.1');
	}
}
add_action('init','simple_syntax_highlighter_init');

function simple_syntax_admin_init() {
	register_setting('simple_syntax_options','simple_syntax_options');
	add_settings_section('syntax_theme_settings', __('Syntax Theme Settings'), 'syntax_theme_section_text', 'syntax-highlighter');
	add_settings_field('syntax_theme_select',__('Syntax Theme'),'syntax_get_themes','syntax-highlighter','syntax_theme_settings');
}
add_action('admin_init','simple_syntax_admin_init');

function syntax_get_current_theme_thumb() {
	$options = get_option('simple_syntax_options');
	$default = 'prettify.css';
	if ( empty($options['theme']) ) $options['theme'] = $default;
	$imageName = preg_replace('/css/','png',$options['theme']);
	$imageUrl = plugins_url("themes/$imageName",__FILE__);
	return $imageUrl;
}

function syntax_get_themes() {
	$options = get_option('simple_syntax_options');
	$default = 'prettify.css';
	if ( empty($options['theme']) ) $options['theme'] = $default;
	
	$theme_files = scandir(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'themes');
	$themes = array();
	foreach ( $theme_files as $file ) {
		if ( preg_match('/[.]css$/',$file) ) {
			$themes[] = $file;
		}
	}
	?>
	<select data-themeurl="<?php echo plugins_url('themes',__FILE__); ?>" name="simple_syntax_options[theme]" id="simple_syntax_options_theme">
		<?php foreach($themes as $theme): 
				$selected = false;
				if ( $theme == $options['theme'] ) { 
					$selected = true;
				}
		?>
		<option value="<?php echo $theme ?>"<?php if ($selected): echo ' selected="selected"'; endif;?>><?php echo $theme; ?></option>
		<?php endforeach; ?>
	</select><?php
}

function syntax_theme_section_text() {?>
	<p><?php  _e('Choose a theme for the syntax highlighter','syntax'); ?><p><?php
}

function simple_syntax_add_admin_page() {
	$page = add_options_page('Simple Syntax Settings','Simple Syntax','manage_options','syntax-highlighter','simple_syntax_admin_page');
	add_action("admin_print_scripts-$page",'simple_syntax_admin_scripts');
	add_action("admin_print_styles-$page",'simple_syntax_admin_styles');
	
}
add_action('admin_menu','simple_syntax_add_admin_page');

function simple_syntax_admin_page() { ?>
	<div class="wrap">
		<h2><?php  _e('Simple Syntax Options','syntax'); ?></h2>
		<form action="options.php" method="post">
			<?php settings_fields('simple_syntax_options'); ?>
			<?php do_settings_sections('syntax-highlighter'); ?>
			<div>
				<h3><?php _e('Current Theme','syntax'); ?></h3>
				<img id="simple-syntax-current-theme" src="<?php echo syntax_get_current_theme_thumb(); ?>" />
			</div>
			<div class="submit">
				<input type="submit" name="Submit" value="Save Changes" />
			</div>
		</form>
	</div>
	<?php
}

function simple_syntax_admin_scripts() {
	$js = plugins_url('js/simple-syntax.js',__FILE__);
	wp_enqueue_script( 'simple-syntax', $js, array(), '0.1', true);
}

function simple_syntax_admin_styles() {
	$css = plugins_url('simple-syntax.css',__FILE__);
	wp_enqueue_style( 'simple-syntax', $css, array(), '0.1');
}
?>
