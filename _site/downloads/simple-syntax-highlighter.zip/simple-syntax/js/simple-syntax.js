(function(){
	//lets keep things simple eh?
	var bindChange = function(fn) {
		if ( document.addEventListener ) {
			this.addEventListener('change',fn,false);
		} else if ( document.attachEvent ) {
			this.attachEvent('onchange',function() { fn.call(event.srcElement) } );
		}
	};

	bindChange.call(document.getElementById('simple_syntax_options_theme'),function(){
		var themeurl = this.getAttribute('data-themeurl'),
			value = this.value,
			png = value.replace(/css/,'png'),
			preview = document.getElementById('simple-syntax-current-theme');

		preview.setAttribute('src',themeurl + '/' + png);
	});
}).call(this);