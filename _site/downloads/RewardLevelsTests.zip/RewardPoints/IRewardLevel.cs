﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public interface IRewardLevel
    {
        Participant Participant { get; set; }

        #region Methods

        void AddPoints(int points);

        void SetPoints(int points);

        #endregion
    }
}
