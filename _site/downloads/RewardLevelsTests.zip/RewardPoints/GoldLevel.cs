﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public class GoldLevel : RewardLevel
    {
        public GoldLevel(Participant p)
        {
            Participant = p;
        }

    }
}
