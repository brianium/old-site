﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public class PlatinumLevel : RewardLevel
    {
        public PlatinumLevel(Participant p)
        {
            Participant = p;
        }
    }
}
