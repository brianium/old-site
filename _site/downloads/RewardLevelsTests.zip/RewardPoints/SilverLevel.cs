﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public class SilverLevel : RewardLevel
    {
        public SilverLevel(Participant p)
        {
            Participant = p;
        }
    }
}
