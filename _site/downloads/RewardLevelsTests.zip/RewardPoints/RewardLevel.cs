﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public abstract class RewardLevel : IRewardLevel
    {
        public Participant Participant { get; set; }

        protected int minimumPoints;
        protected int maximumPoints;

        public void AddPoints(int points)
        {
            Participant.Points += points;
            CheckState();
        }

        public void SetPoints(int points)
        {
            Participant.Points = points;
            CheckState();
        }

        protected void CheckState()
        {
            var p = Participant.Points;
            if (p >= 0 && p < 26)
                Participant.RewardLevel = new BronzeLevel(Participant);
            else if (p > 25 && p < 51)
                Participant.RewardLevel = new SilverLevel(Participant);
            else if (p > 50 && p < 101)
                Participant.RewardLevel = new GoldLevel(Participant);
            else if (p > 100)
                Participant.RewardLevel = new PlatinumLevel(Participant);
        }
    }
}
