﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public class Participant
    {
        public string Name { get; set; }

        public int Points { get; set; }

        public RewardLevel RewardLevel { get; set; }

        public Participant(string name, int points)
        {
            Name = name;
            Points = points;
            RewardLevel = new BronzeLevel(this);
            RewardLevel.SetPoints(points);
        }

        public void AddPoints(int points)
        {
            RewardLevel.AddPoints(points);
        }

        public void SetPoints(int points)
        {
            RewardLevel.SetPoints(points);
        }
    }
}
