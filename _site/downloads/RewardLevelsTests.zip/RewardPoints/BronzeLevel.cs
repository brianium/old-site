﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RewardLevels
{
    public class BronzeLevel : RewardLevel
    {
        public BronzeLevel(Participant p)
        {
            Participant = p;
        }
    }
}
