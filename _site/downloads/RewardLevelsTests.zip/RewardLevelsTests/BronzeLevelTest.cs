﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using RewardLevels;

namespace RewardLevelsTests
{
    [TestFixture]
    class BronzeLevelTest
    {
        public BronzeLevel BronzeLevel;

        [SetUp]
        public void Init()
        {
            BronzeLevel = new BronzeLevel(new Participant("Brian", 10));
        }

        [Test]
        public void IsDerivedFromRewardLevel()
        {
            Assert.IsInstanceOf<RewardLevel>(BronzeLevel);
        }

        [Test]
        public void ParticipantProperty()
        {
            Assert.IsInstanceOf<Participant>(BronzeLevel.Participant);
            Assert.AreEqual(10, BronzeLevel.Participant.Points);
        }

        [Test]
        public void AddPoints()
        {
            BronzeLevel.AddPoints(5);
            Assert.AreEqual(15, BronzeLevel.Participant.Points);
        }

        [Test]
        public void SetPoints()
        {
            BronzeLevel.SetPoints(10);
            Assert.AreEqual(10, BronzeLevel.Participant.Points);
        }

        [Test]
        public void AddingPointsAboveUpperBoundChangesParticipantStateToSilverLevel()
        {
            BronzeLevel.SetPoints(10);
            BronzeLevel.AddPoints(16);
            Assert.AreEqual("SilverLevel", BronzeLevel.Participant.RewardLevel.GetType().Name);
        }

        [Test]
        public void SettingPointsAboveUpperBoundChangesParticipantStateToSilverLevel()
        {
            BronzeLevel.SetPoints(30);
            Assert.AreEqual("SilverLevel", BronzeLevel.Participant.RewardLevel.GetType().Name);
        }
    }
}
