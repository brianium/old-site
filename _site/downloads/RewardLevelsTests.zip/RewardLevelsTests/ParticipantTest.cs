﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RewardLevels;
using NUnit.Framework;

namespace RewardLevelsTests
{
    [TestFixture]
    public class ParticipantTest
    {
        [Test]
        public void Constructor()
        {
            var p = new Participant("Brian",10);
            Assert.AreEqual("Brian", p.Name);
            Assert.AreEqual(10, p.Points);
            Assert.AreEqual("BronzeLevel", p.RewardLevel.GetType().Name);
        }

        [Test]
        public void ConstructingWithMoreThanBronzeMaximumSetsRewardLevelToSilver()
        {
            var p = new Participant("Bryce", 26);
            Assert.AreEqual("SilverLevel", p.RewardLevel.GetType().Name);
        }

        [Test]
        public void ConstructingWithMoreThanSilverMaximumSetsRewardLevelToGold()
        {
            var p = new Participant("Jennie", 51);
            Assert.AreEqual("GoldLevel", p.RewardLevel.GetType().Name);
        }

        [Test]
        public void AddPoints()
        {
            var p = new Participant("Brian", 0);
            p.AddPoints(26);
            Assert.AreEqual("SilverLevel", p.RewardLevel.GetType().Name);
        }

        [Test]
        public void SetPoints()
        {
            var p = new Participant("Bryce", 0);
            p.SetPoints(150);
            Assert.AreEqual("PlatinumLevel", p.RewardLevel.GetType().Name);
        }

    }
}
