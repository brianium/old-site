﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Moq;
using Moq.Proxy;
using RewardLevels;

namespace RewardLevelsTests
{
    [TestFixture]
    public class IRewardLevelTest
    {
        public Mock<IRewardLevel> RewardLevel = new Mock<IRewardLevel>();

        [Test]
        public void RewardLevelHasParticipantProperty()
        {
            RewardLevel.Setup(rl => rl.Participant).Returns(new Participant("test",10));
            Assert.IsInstanceOf<Participant>(RewardLevel.Object.Participant);
        }

        [Test]
        public void AddPoints()
        {
            IRewardLevel level = RewardLevel.Object;
            level.AddPoints(10);
            RewardLevel.Verify(rl => rl.AddPoints(10));
        }

        [Test]
        public void SetPoints()
        {
            IRewardLevel level = RewardLevel.Object;
            level.SetPoints(10);
            RewardLevel.Verify(rl => rl.SetPoints(10));
        }
    }
}
