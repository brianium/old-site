﻿using System;
using System.Web;
using System.IO;
using System.Web.UI.HtmlControls;

public class BasePage : System.Web.UI.Page
{

    private void Page_Load(object sender, EventArgs e)
    {
        string selectedTheme = Page.Theme;
        if (!string.IsNullOrEmpty(selectedTheme))
        {
            switch (selectedTheme)
            {
                case "Grid":
                    AddStyleSheet("http://fonts.googleapis.com/css?family=Droid+Sans|Lobster");
                    break;
                case "Midnight":
                    AddStyleSheet("http://fonts.googleapis.com/css?family=Open+Sans|Oswald");
                    break;
            }
        }
    }

    private void Page_PreInit(object sender, EventArgs e)
    {
        HttpCookie userTheme = Request.Cookies.Get("UserTheme");
        if (userTheme != null)
        {
            string themePath = Request.PhysicalApplicationPath + "App_Themes" + '\\' + userTheme.Value;
            if (Directory.Exists(themePath))
            {
                Page.Theme = userTheme.Value;
            }
        }
    }

    public BasePage()
    {
        this.Load += new EventHandler(Page_Load);
        this.PreInit += new EventHandler(Page_PreInit);
    }

    private void AddStyleSheet(string href)
    {
        HtmlLink link = new HtmlLink();
        link.Attributes.Add("rel", "stylesheet");
        link.Attributes.Add("media", "all");
        link.Attributes.Add("href", href);
        link.Attributes.Add("type", "text/css");
        Header.Controls.Add(link);
    }
}