﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        pnlForm.Visible = false;
        litName.Text = txtName.Text;
        litSnack.Text = ddlSnack.SelectedItem.Value;
        List<String> toppings = lbToppings.Items.Cast<ListItem>().Where(s => s.Selected).Select(s => s.Value).ToList();
        litToppings.Text = "<span class=\"pizza-item\">" + string.Join("</span>,<span class=\"pizza-item\"> ", toppings.ToArray()) + "</span>";
        if (toppings.Count.Equals(0))
        {
            litToppings.Text = "Plain is fine for me";
        }
        List<String> seasonings = cblSeasoning.Items.Cast<ListItem>().Where(c => c.Selected).Select(c => c.Value).ToList();
        litSeasoning.Text = "<span class=\"pizza-item\">" + string.Join("</span>,<span class=\"pizza-item\"> ", seasonings.ToArray()) + "</span>";
        if (seasonings.Count.Equals(0))
        {
            litSeasoning.Text = "nothing";
        }
        litPisan.Text = rblPisan.SelectedValue;
        pnlMessage.Visible = true;
    }
}