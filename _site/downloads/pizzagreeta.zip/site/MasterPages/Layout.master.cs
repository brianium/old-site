﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPages_Layout : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string selectedTheme = Page.Theme;
            HttpCookie userTheme = Request.Cookies.Get("UserTheme");
            if (userTheme != null)
            {
                selectedTheme = userTheme.Value;
            }
            if (!string.IsNullOrEmpty(selectedTheme) && ddlThemes.Items.FindByValue(selectedTheme) != null)
            {
                ddlThemes.Items.FindByValue(selectedTheme).Selected = true;
            }
        }
    }

    protected void ddlThemes_SelectedIndexChanged(object sender, EventArgs e)
    {
        HttpCookie userTheme = new HttpCookie("UserTheme")
        {
            Expires = DateTime.Now.AddMonths(3),
            Value = ddlThemes.SelectedValue
        };
        Response.Cookies.Add(userTheme);
        Response.Redirect(Request.Url.ToString());
    }
}
